public class Test {

    
    public static int add(int... numbers) {
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        return sum;
    }

    public static void main(String[] args) {
      
        System.out.println("Sum of 1, 2, 3: " + add(1, 2, 3));
        System.out.println("Sum of 10, 20, 30, 40: " + add(10, 20, 30, 40));
        System.out.println("Sum of 5, 10, 15, 20, 25: " + add(5, 10, 15, 20, 25));
        System.out.println("Sum with no arguments: " + add());
    }
}
