import java.util.Scanner;


class ThreadDemo implements Runnable {
    @Override
    public void run() {
        // Run method logic
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " Count: " + i);
            try {
                Thread.sleep(10000000);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}


class Thread1 extends ThreadDemo {
    int a;

    public Thread1(int a) {
        this.a = a;
    }

    @Override
    public void run() {
        super.run();  // Run the base class logic first
        for (int i = a; i <= a + 10; i++) {
            System.out.println("Addition: " + i);
        }
    }
}


class Thread2 extends ThreadDemo {
    int a;

    public Thread2(int a) {
        this.a = a;
    }

    @Override
    public void run() {
        super.run();  // Run the base class logic first
        for (int i = 1; i <= 10; i++) {
            System.out.println(a + " * " + i + " : " + (a * i));
        }
    }
}

public class Tester3 {
    public static void main(String[] args) {
        int a, b;
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter the value for addition:");
            a = sc.nextInt();
            System.out.println("Enter the value for multiplication table:");
            b = sc.nextInt();

            
            Thread1 additionTask = new Thread1(a);
            Thread2 multiplicationTask = new Thread2(b);

          
            Thread additionThread = new Thread(additionTask, "Addition Thread");
            Thread multiplicationThread = new Thread(multiplicationTask, "Multiplication Thread");

           
            additionThread.start();
            multiplicationThread.start();
        } finally {
            sc.close();  
        }
    }
}
