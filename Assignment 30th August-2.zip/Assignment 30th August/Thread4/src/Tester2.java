import java.util.Scanner;

class Thread1 extends Thread { 
    int a;

    public Thread1(int a) {
        this.a = a;
    }

    public void run() {
        for (int i = a; i <= a + 10; i++) {
            System.out.println("Addition: " + i);
        }
    }
}

class Thread2 extends Thread { 
    int a;

    public Thread2(int a) {
        this.a = a;
    }

    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(a + " * " + i + " : " + (a * i));  
        }
    }
}

public class Tester2 {
    public static void main(String args[]) {
        int a, b;
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter the value for addition:");
            a = sc.nextInt();
            System.out.println("Enter the value for multiplication table:");
            b = sc.nextInt();
            Thread1 t1 = new Thread1(a);  
            t1.start();
            Thread2 t2 = new Thread2(b);  
            t2.start();
        } finally {
            sc.close();  
        }
    }
}
