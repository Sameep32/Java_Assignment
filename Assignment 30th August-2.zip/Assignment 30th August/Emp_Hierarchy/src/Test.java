class Employee {
    private int employeeId;
    private String name;
    protected double basicSalary;

    public Employee(int employeeId, String name, double basicSalary) {
        this.employeeId = employeeId;
        this.name = name;
        this.basicSalary = basicSalary;
    }

    public void display() {
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Name: " + name);
        System.out.println("Basic Salary: " + basicSalary);
    }

    public double calculatePF() {
        return 0.125 * basicSalary;
    }
}

class Manager extends Employee {
    public Manager(int employeeId, String name, double basicSalary) {
        super(employeeId, name, basicSalary);
    }

    public double calculateGrossSalary() {
        double petrolAllowance = 0.08 * basicSalary;
        double foodAllowance = 0.12 * basicSalary;
        double otherAllowance = 0.04 * basicSalary;
        return basicSalary + petrolAllowance + foodAllowance + otherAllowance;
    }

    public double calculateNetSalary() {
        double grossSalary = calculateGrossSalary();
        return grossSalary - calculatePF();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Gross Salary: " + calculateGrossSalary());
        System.out.println("Net Salary: " + calculateNetSalary());
    }
}

class MarketingExecutive extends Employee {
    private double kilometersTravelled;

    public MarketingExecutive(int employeeId, String name, double basicSalary, double kilometersTravelled) {
        super(employeeId, name, basicSalary);
        this.kilometersTravelled = kilometersTravelled;
    }

    public double calculateGrossSalary() {
        double tourAllowance = 5 * kilometersTravelled;
        double telephoneAllowance = 2000;
        return basicSalary + tourAllowance + telephoneAllowance;
    }

    public double calculateNetSalary() {
        double grossSalary = calculateGrossSalary();
        return grossSalary - calculatePF();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Kilometers Travelled: " + kilometersTravelled);
        System.out.println("Gross Salary: " + calculateGrossSalary());
        System.out.println("Net Salary: " + calculateNetSalary());
    }
}

public class Test {
    public static void main(String[] args) {
        Manager manager = new Manager(1, "Sameep", 50000);
        manager.display();
        
        MarketingExecutive marketingExecutive = new MarketingExecutive(2, "Rajesh", 40000, 300);
        marketingExecutive.display();
    }
}
