import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            // Establish database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/sameep", "root", "root");
            
            while (true) {
                System.out.println("\nMenu:");
                System.out.println("1. Insert record");
                System.out.println("2. Update record");
                System.out.println("3. Delete record");
                System.out.println("4. Display particular record");
                System.out.println("5. Display all records");
                System.out.println("6. Exit");
                System.out.print("Choose an option: ");
                int choice = sc.nextInt();
                
                switch (choice) {
                    case 1:
                        insertRecord(conn, sc);
                        break;
                    case 2:
                        updateRecord(conn, sc);
                        break;
                    case 3:
                        deleteRecord(conn, sc);
                        break;
                    case 4:
                        displayParticularRecord(conn, sc);
                        break;
                    case 5:
                        displayAllRecords(conn);
                        break;
                    case 6:
                        conn.close();
                        System.out.println("Exiting program.");
                        sc.close();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertRecord(Connection conn, Scanner sc) throws SQLException {
        System.out.println("Enter RollNo, Name, Percentage:");
        int rno = sc.nextInt();
        String name = sc.next();
        long percentage = sc.nextLong();

        PreparedStatement psmt = conn.prepareStatement("INSERT INTO student VALUES (?, ?, ?)");
        psmt.setInt(1, rno);
        psmt.setString(2, name);
        psmt.setLong(3, percentage);

        int rowsAffected = psmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Record inserted successfully.");
        }
    }

    private static void updateRecord(Connection conn, Scanner sc) throws SQLException {
        System.out.println("Enter RollNo of the student to update:");
        int rno = sc.nextInt();
        System.out.println("Enter new Name and Percentage:");
        String name = sc.next();
        long percentage = sc.nextLong();

        PreparedStatement psmt = conn.prepareStatement("UPDATE student SET name = ?, percentage = ? WHERE rno = ?");
        psmt.setString(1, name);
        psmt.setLong(2, percentage);
        psmt.setInt(3, rno);

        int rowsAffected = psmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Record updated successfully.");
        } else {
            System.out.println("No record found with the given RollNo.");
        }
    }

    private static void deleteRecord(Connection conn, Scanner sc) throws SQLException {
        System.out.println("Enter RollNo of the student to delete:");
        int rno = sc.nextInt();

        PreparedStatement psmt = conn.prepareStatement("DELETE FROM student WHERE rno = (?)");
        psmt.setInt(1, rno);

        boolean rowsAffected = psmt.execute();
        if (!rowsAffected) {
            System.out.println("Record deleted successfully.");
        } else {
            System.out.println("No record found with the given RollNo.");
        }
    }

    private static void displayParticularRecord(Connection conn, Scanner sc) throws SQLException {
        System.out.println("Enter RollNo of the student to display:");
        int rno = sc.nextInt();

        PreparedStatement psmt = conn.prepareStatement("SELECT * FROM student WHERE rno = ?");
        psmt.setInt(1, rno);

        ResultSet rs = psmt.executeQuery();
        if (rs.next()) {
            System.out.println("RollNo: " + rs.getInt("rno") + ", Name: " + rs.getString("name") + ", Percentage: " + rs.getLong("percentage"));
        } else {
            System.out.println("No record found with the given RollNo.");
        }
    }

    private static void displayAllRecords(Connection conn) throws SQLException {
        PreparedStatement psmt = conn.prepareStatement("SELECT * FROM student");

        ResultSet rs = psmt.executeQuery();
        while (rs.next()) {
            System.out.println("RollNo: " + rs.getInt("rno") + ", Name: " + rs.getString("name") + ", Percentage: " + rs.getLong("percentage"));
        }
    }
}
