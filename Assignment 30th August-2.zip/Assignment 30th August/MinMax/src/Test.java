
public class Test {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] number = {1,2,3,4,5,6,7,8,9,10};
		
		int largest = number[0];
		int smallest = number[0];
		
		for(int i = 0; i < number.length; i++) {
			if (number[i]>largest) {
				largest = number[i];
			} 
			else if(number[i]<smallest) {
				smallest = number[i];
			}
		}
		System.out.println("Largest number is:" + largest);
		System.out.println("Smallest number is: " + smallest);
		
		int b[] = new int[10];
		
		
		for(int i = 0; i<b.length; i++) {
			b[i] =number[i]*5;
			System.out.println(b[i] + " ");
			}
		
		
	}

}
