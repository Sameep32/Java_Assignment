import java.util.Scanner;

public class Test {
    private static int rollNumberCounter = 1;
    private int rollNumber;
    private String name;
    private Date dateOfBirth;

    public Test() {
        this.rollNumber = rollNumberCounter++;
        this.name = "";
        this.dateOfBirth = new Date();
    }

    public Test(String name, Date dateOfBirth) {
        this.rollNumber = rollNumberCounter++;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public void acceptDetails() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Student Name: ");
        this.name = scanner.nextLine();
        System.out.print("Enter Date of Birth (day month year): ");
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        this.dateOfBirth = new Date(day, month, year);
    }

    public void displayDetails() {
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Name: " + name);
        System.out.print("Date of Birth: ");
        dateOfBirth.displayDate();
    }

    public static void main(String[] args) {
        Test student1 = new Test();
        student1.acceptDetails();
        student1.displayDetails();
        Date dob = new Date(15, 8, 2000);
        Test student2 = new Test("Alice", dob);
        student2.displayDetails();
    }

    static class Date {
        private int day;
        private int month;
        private int year;

        public Date() {
            this.day = 1;
            this.month = 1;
            this.year = 2000;
        }

        public Date(int day, int month, int year) {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public void displayDate() {
            System.out.println(day + "/" + month + "/" + year);
        }

        public int getDay() {
            return day;
        }

        public void setDay(int day) {
            this.day = day;
        }

        public int getMonth() {
            return month;
        }

        public void setMonth(int month) {
            this.month = month;
        }

        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }
    }
}
