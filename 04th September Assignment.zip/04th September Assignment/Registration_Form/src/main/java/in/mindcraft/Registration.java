package in.mindcraft;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Registration {

    @RequestMapping("/register")
    public ModelAndView register(HttpServletRequest request, HttpServletResponse response) {

        System.out.println("Registration is called...");
        String name = request.getParameter("name");
        String number = request.getParameter("number");
        String email = request.getParameter("email");
        String gender = request.getParameter("gender");

        // Validation checks
        if (!name.matches("[A-Za-z\\s]+")) {
            ModelAndView mv = new ModelAndView();
            mv.setViewName("index.jsp");
            mv.addObject("error", "Invalid name. Name should contain only letters.");
            return mv;
        }

        if (number.matches("^[1-9][0-9]{9}$")) {
            ModelAndView mv = new ModelAndView();
            mv.setViewName("result.jsp");
            mv.addObject("message", "Registration successful!");
            mv.addObject("name", name);
            mv.addObject("number", number);
            mv.addObject("email", email);
            mv.addObject("gender", gender);
            return mv;
        } else {
            ModelAndView mv = new ModelAndView();
            mv.setViewName("index.jsp");
            mv.addObject("error", "Invalid number. Must be 10 digits and cannot start with zero.");
            return mv;
        }
    }
}
