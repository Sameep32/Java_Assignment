import java.util.Scanner;

public class Test {
    private int rollNo;
    private String name;
    private double percentage;
    
    
    private static int count = 0;

  
    public Test(int rollNo, String name, double percentage) {
        this.rollNo = rollNo;
        this.name = name;
        this.percentage = percentage;
        count++;  
    }

    
    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    
    public static int getCount() {
        return count;
    }

   
    public void displayInfo() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Percentage: " + percentage);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the number of students: ");
        int numberOfStudents = sc.nextInt();
        sc.nextLine(); 

        Test[] students = new Test[numberOfStudents];

        // Input student details
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println("Enter details for student " + (i + 1) + ":");
            
            System.out.print("Enter roll number: ");
            int rollNo = sc.nextInt();
            sc.nextLine(); 
            
            System.out.print("Enter name: ");
            String name = sc.nextLine();
            
            System.out.print("Enter percentage: ");
            double percentage = sc.nextDouble();
            sc.nextLine(); 
            
            students[i] = new Test(rollNo, name, percentage);
        }
        
       
        System.out.println("\nStudent Details:");
        for (Test student : students) {
            student.displayInfo();
            System.out.println();
        }

        
        System.out.println("Number of Student objects created: " + Test.getCount());

      
    }
}
