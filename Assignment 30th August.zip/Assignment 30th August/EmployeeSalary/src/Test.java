import java.util.Scanner;

class Employee {
    private int employeeId;
    private String name;
    private Date dateOfBirth;

    public Employee(int employeeId, String name, Date dateOfBirth) {
        this.employeeId = employeeId;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public void displayDetails() {
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Name: " + name);
        System.out.print("Date of Birth: ");
        dateOfBirth.displayDate();
    }
}

class WageEmployee extends Employee {
    private int hoursWorked;
    private double ratePerHour;

    public WageEmployee(int employeeId, String name, Date dateOfBirth, int hoursWorked, double ratePerHour) {
        super(employeeId, name, dateOfBirth);
        this.hoursWorked = hoursWorked;
        this.ratePerHour = ratePerHour;
    }

    public double calculateSalary() {
        return hoursWorked * ratePerHour;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Hours Worked: " + hoursWorked);
        System.out.println("Rate per Hour: " + ratePerHour);
        System.out.println("Salary: " + calculateSalary());
    }
}

class SalesPerson extends WageEmployee {
    private int itemsSold;
    private double commissionPerItem;

    public SalesPerson(int employeeId, String name, Date dateOfBirth, int hoursWorked, double ratePerHour, int itemsSold, double commissionPerItem) {
        super(employeeId, name, dateOfBirth, hoursWorked, ratePerHour);
        this.itemsSold = itemsSold;
        this.commissionPerItem = commissionPerItem;
    }

    @Override
    public double calculateSalary() {
        return super.calculateSalary() + (itemsSold * commissionPerItem);
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Items Sold: " + itemsSold);
        System.out.println("Commission per Item: " + commissionPerItem);
        System.out.println("Total Salary: " + calculateSalary());
    }
}

class Date {
    private int day;
    private int month;
    private int year;

    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public void displayDate() {
        System.out.println(day + "/" + month + "/" + year);
    }
}

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Employee Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Date of Birth (day month year): ");
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        Date dob = new Date(day, month, year);
        System.out.print("Enter Hours Worked: ");
        int hoursWorked = scanner.nextInt();
        System.out.print("Enter Rate per Hour: ");
        double ratePerHour = scanner.nextDouble();
        System.out.print("Enter Items Sold: ");
        int itemsSold = scanner.nextInt();
        System.out.print("Enter Commission per Item: ");
        double commissionPerItem = scanner.nextDouble();

        SalesPerson salesPerson = new SalesPerson(employeeId, name, dob, hoursWorked, ratePerHour, itemsSold, commissionPerItem);
        salesPerson.displayDetails();
        
       
    }
}
